<<<<<<< HEAD
# Shape-Ships-AI
A neon-styled Space Shooter game in Processing with AI-driven custom enemies featuring homing, shielding, and orbiting behaviors.”
=======
# ShapeShipsAI

A neon-styled *Geometry Wars: Retro Evolved* clone built in Processing 4.4.1, featuring AI-driven custom enemies with dynamic behaviors like homing, shielding, and orbiting. Developed for an AI portfolio.

## Features
- **AI-Driven Enemies**: Custom enemies spawn in stage 5 (score ≥ 200, kill rate ≥ 5, time ≥ 60s) with attributes (homing, shielding, orbiting, erratic, boomerang), shapes (pentagon, octagon, star, heptagon, cross, triangle), and neon colors.
- **Dynamic Difficulty**: Enemy volume scales from 1 to 2 enemies/s over 300s, with 6–20% custom enemy probability.
- **Controls**: Arrow keys (move), left-click (shoot), right-click (black hole), space (restart).
- **Visuals**: Neon cyan/pink grid, glowing enemies, 60 FPS with P2D renderer.

## Installation
1. Install [Processing 4.4.1](https://processing.org/download).
2. Clone this repository:
   ```bash
   git clone https://github.com/Kirby-Manjarres/Shape-Ships-AI
>>>>>>> 32a46d8 (Initial commit: GeometryWars Processing sketch with AI-driven custom enemies)
